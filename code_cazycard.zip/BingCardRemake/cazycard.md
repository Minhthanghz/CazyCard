# CazyCard - Virtual Card Management Platform

## Overview

CazyCard is a full-stack web application for generating and managing virtual credit cards. The platform provides users with the ability to create VISA and Mastercard virtual cards, manage deposits via USDT-BEP20, and track transactions. It features a modern dashboard interface with admin controls for deposit approvals and user management.

The application follows a monorepo structure with a React frontend, Express.js backend, PostgreSQL database with Drizzle ORM, and integrates with external virtual card generation APIs.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for development and production builds
- **UI Components**: Radix UI primitives with shadcn/ui component library
- **Styling**: Tailwind CSS with custom cyberpunk-inspired color scheme (blue-yellow-dark theme)
- **State Management**: TanStack Query for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Form Management**: React Hook Form with Zod validation
- **Session Handling**: Cookie-based sessions with express-session

### Backend Architecture
- **Runtime**: Node.js with TypeScript and ESM modules
- **Framework**: Express.js with RESTful API design
- **Authentication**: Session-based authentication with bcrypt password hashing
- **Session Storage**: In-memory storage with express-session and MemoryStore
- **API Structure**: Role-based endpoints with authentication and admin middleware
- **Error Handling**: Centralized error handling with structured error responses
- **Development**: Hot reload with tsx and Vite integration

### Database Design
- **Database**: PostgreSQL with Neon serverless driver
- **ORM**: Drizzle ORM with TypeScript schema definitions
- **Schema Structure**:
  - Users table with role-based access (admin/user)
  - Deposits table for USDT-BEP20 transaction tracking
  - Virtual cards table for generated card management
  - Transactions table for audit trail and balance tracking
- **Data Types**: Decimal precision for financial calculations, UUID primary keys
- **Migrations**: Drizzle-kit for schema migrations

### Authentication & Authorization
- **User Authentication**: Username/password with bcrypt hashing
- **Session Management**: Server-side sessions with secure HTTP-only cookies
- **Authorization Levels**: 
  - Regular users: Card generation, deposit management, transaction history
  - Admin users: User management, deposit approvals, system statistics
- **Default Admin**: Username "admin", Password "admin123"

### External Dependencies

- **Virtual Card API**: Integration with web.gpaycard.world API for card generation
- **Database Provider**: Neon PostgreSQL serverless database
- **UI Framework**: Radix UI component primitives
- **Development Tools**: 
  - Cazycard-specific plugins for development environment
  - Font Awesome for card type icons
  - QR code generation for crypto deposit addresses
- **Cryptocurrency**: USDT-BEP20 wallet integration for deposits
- **Session Store**: In-memory session storage (MemoryStore)
- **Build Pipeline**: ESBuild for production server bundling