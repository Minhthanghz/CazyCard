import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { cn } from "@/lib/utils";
import {
  LayoutDashboard,
  Wallet,
  PlusCircle,
  CreditCard,
  History,
  Users,
  CheckCircle,
  BarChart,
  Settings,
} from "lucide-react";

interface NavItem {
  href: string;
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  adminOnly?: boolean;
}

const navItems: NavItem[] = [
  {
    href: "/dashboard",
    icon: LayoutDashboard,
    label: "Dashboard",
  },
  {
    href: "/wallet",
    icon: Wallet,
    label: "Wallet",
  },
  {
    href: "/generate",
    icon: PlusCircle,
    label: "Generate Card",
  },
  {
    href: "/cards",
    icon: CreditCard,
    label: "My Cards",
  },
  {
    href: "/transactions",
    icon: History,
    label: "Transactions",
  },
  {
    href: "/admin/users",
    icon: Users,
    label: "User Management",
    adminOnly: true,
  },
  {
    href: "/admin/deposits",
    icon: CheckCircle,
    label: "Deposit Approval",
    adminOnly: true,
  },
  {
    href: "/admin/stats",
    icon: BarChart,
    label: "System Stats",
    adminOnly: true,
  },
  {
    href: "/settings",
    icon: Settings,
    label: "Settings",
  },
];

export default function Sidebar() {
  const [location] = useLocation();
  const { user } = useAuth();

  const visibleItems = navItems.filter(item => !item.adminOnly || user?.isAdmin);
  const adminItems = visibleItems.filter(item => item.adminOnly);
  const regularItems = visibleItems.filter(item => !item.adminOnly);

  return (
    <aside className="w-64 bg-card border-r border-border h-full">
      <nav className="p-6 space-y-2">
        {regularItems.map((item) => {
          const Icon = item.icon;
          const isActive = location === item.href;
          
          return (
            <Link key={item.href} href={item.href}>
              <a className={cn(
                "flex items-center px-3 py-2 rounded-lg font-medium transition-colors",
                isActive 
                  ? "text-primary bg-primary/10"
                  : "text-muted-foreground hover:text-foreground hover:bg-accent"
              )} data-testid={`nav-${item.href.replace('/', '')}`}>
                <Icon className="w-5 h-5 mr-3" />
                {item.label}
              </a>
            </Link>
          );
        })}
        
        {adminItems.length > 0 && (
          <div className="pt-4 border-t border-border">
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">
              Admin
            </p>
            {adminItems.map((item) => {
              const Icon = item.icon;
              const isActive = location === item.href;
              
              return (
                <Link key={item.href} href={item.href}>
                  <a className={cn(
                    "flex items-center px-3 py-2 rounded-lg font-medium transition-colors",
                    isActive 
                      ? "text-primary bg-primary/10"
                      : "text-muted-foreground hover:text-foreground hover:bg-accent"
                  )} data-testid={`nav-admin-${item.href.split('/').pop()}`}>
                    <Icon className="w-5 h-5 mr-3" />
                    {item.label}
                  </a>
                </Link>
              );
            })}
          </div>
        )}
      </nav>
    </aside>
  );
}
