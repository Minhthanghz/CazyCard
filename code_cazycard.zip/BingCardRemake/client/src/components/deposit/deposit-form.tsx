import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { generateWalletQR } from "@/lib/qr-code";
import { Copy, QrCode } from "lucide-react";

const DEPOSIT_AMOUNTS = [50, 100, 200, 500, 1000, 2000, 5000];
const WALLET_ADDRESS = "0x463f5d4c8a62403a0a28a60712347ae215dab39c";

export default function DepositForm() {
  const [selectedAmount, setSelectedAmount] = useState<number | null>(null);
  const [exactAmount, setExactAmount] = useState<string>("");
  const [showDetails, setShowDetails] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const createDepositMutation = useMutation({
    mutationFn: async (amount: number) => {
      const response = await apiRequest("POST", "/api/deposits", { amount: amount.toString() });
      return response.json();
    },
    onSuccess: (data) => {
      setExactAmount(data.exactAmount);
      setShowDetails(true);
      queryClient.invalidateQueries({ queryKey: ["/api/deposits"] });
      toast({
        title: "Deposit Request Created",
        description: "Your deposit request has been generated successfully.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create deposit request",
        variant: "destructive",
      });
    },
  });

  const handleAmountSelect = (amount: number) => {
    setSelectedAmount(amount);
    setShowDetails(false);
  };

  const handleGenerateDeposit = () => {
    if (!selectedAmount) return;
    createDepositMutation.mutate(selectedAmount);
  };

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast({
        title: "Copied",
        description: "Address copied to clipboard",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to copy address",
        variant: "destructive",
      });
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Make Deposit</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {DEPOSIT_AMOUNTS.map((amount) => (
            <Button
              key={amount}
              variant={selectedAmount === amount ? "default" : "outline"}
              className="p-3 h-auto"
              onClick={() => handleAmountSelect(amount)}
              data-testid={`button-amount-${amount}`}
            >
              <div className="font-semibold">${amount}</div>
            </Button>
          ))}
          <Button
            variant={selectedAmount === -1 ? "default" : "outline"}
            className="p-3 h-auto border-dashed"
            onClick={() => handleAmountSelect(-1)}
            data-testid="button-amount-custom"
          >
            <div className="font-semibold">Custom</div>
          </Button>
        </div>

        {showDetails && exactAmount && (
          <div className="space-y-6">
            <div className="bg-accent p-4 rounded-lg">
              <p className="text-sm font-medium mb-2">Send exactly this amount:</p>
              <div className="text-lg font-bold text-primary" data-testid="text-exact-amount">
                {exactAmount} USDT
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium mb-2">
                  Wallet Address (BEP-20)
                </label>
                <div className="flex items-center bg-secondary p-3 rounded-lg">
                  <span className="text-sm font-mono flex-1" data-testid="text-wallet-address">
                    {WALLET_ADDRESS}
                  </span>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => copyToClipboard(WALLET_ADDRESS)}
                    data-testid="button-copy-address"
                  >
                    <Copy className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              
              <div className="flex flex-col items-center">
                <label className="block text-sm font-medium mb-2">QR Code</label>
                <div className="w-32 h-32 bg-secondary rounded-lg flex items-center justify-center">
                  <img
                    src={generateWalletQR(WALLET_ADDRESS, exactAmount)}
                    alt="Wallet QR Code"
                    className="w-28 h-28 rounded"
                    data-testid="img-qr-code"
                  />
                </div>
              </div>
            </div>

            <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
              <div className="flex items-start">
                <div className="text-sm text-yellow-800">
                  <p className="font-medium mb-2">Important Instructions:</p>
                  <ul className="list-disc list-inside space-y-1">
                    <li>Send exactly the amount shown above</li>
                    <li>Use only USDT on BEP-20 network</li>
                    <li>Admin will manually verify and approve deposits</li>
                    <li>Processing may take 15-30 minutes</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        )}

        <Button
          onClick={handleGenerateDeposit}
          className="w-full"
          disabled={!selectedAmount || createDepositMutation.isPending}
          data-testid="button-generate-deposit"
        >
          {createDepositMutation.isPending ? "Generating..." : "Generate Deposit Request"}
        </Button>
      </CardContent>
    </Card>
  );
}
