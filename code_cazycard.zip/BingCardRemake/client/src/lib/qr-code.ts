// QR Code generation utility
export function generateQRCodeDataURL(text: string, size: number = 200): string {
  // Using a simple QR code generator approach
  // In production, you might want to use a dedicated QR library
  const encodedText = encodeURIComponent(text);
  return `https://api.qrserver.com/v1/create-qr-code/?size=${size}x${size}&data=${encodedText}`;
}

export function generateWalletQR(address: string, amount: string): string {
  const bep20URI = `ethereum:${address}?value=${amount}`;
  return generateQRCodeDataURL(bep20URI, 256);
}
