import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useLocation } from "wouter";
import CardPreview from "@/components/cards/card-preview";
import { PlusCircle } from "lucide-react";

const BALANCE_OPTIONS = [50, 100, 250, 500];

export default function GenerateCard() {
  const { user } = useAuth();
  const [cardType, setCardType] = useState<string>("");
  const [balance, setBalance] = useState<string>("");
  const [customBalance, setCustomBalance] = useState<string>("");
  const [usage, setUsage] = useState<string>("online");
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [, setLocation] = useLocation();

  const selectedBalance = balance === "custom" ? customBalance : balance;
  const totalCost = selectedBalance ? parseFloat(selectedBalance) + 2 : 0;
  const canGenerate = cardType && selectedBalance && parseFloat(selectedBalance) > 0 && totalCost <= parseFloat(user?.balance || "0");

  const generateCardMutation = useMutation({
    mutationFn: async (data: { cardType: string; balance: string }) => {
      const response = await apiRequest("POST", "/api/cards", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cards"] });
      queryClient.invalidateQueries({ queryKey: ["/api/me"] });
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      toast({
        title: "Card Generated Successfully",
        description: "Your virtual card has been created and is ready to use.",
      });
      setLocation("/cards");
    },
    onError: (error: any) => {
      toast({
        title: "Generation Failed",
        description: error.message || "Failed to generate virtual card",
        variant: "destructive",
      });
    },
  });

  const handleGenerate = () => {
    if (!canGenerate) return;
    
    generateCardMutation.mutate({
      cardType,
      balance: selectedBalance,
    });
  };

  return (
    <div className="p-6">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-foreground mb-2" data-testid="text-generate-title">
          Generate Virtual Card
        </h1>
        <p className="text-muted-foreground">
          Create a new virtual card for secure online payments.
        </p>
      </div>

      <div className="max-w-4xl">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Card Configuration */}
          <Card>
            <CardHeader>
              <CardTitle>Card Configuration</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <Label className="text-sm font-medium mb-3 block">Card Type</Label>
                <div className="grid grid-cols-2 gap-4">
                  <Button
                    variant={cardType === "visa" ? "default" : "outline"}
                    className="h-20 flex flex-col items-center justify-center"
                    onClick={() => setCardType("visa")}
                    data-testid="button-card-type-visa"
                  >
                    <i className="fab fa-cc-visa text-2xl text-blue-600 mb-2" />
                    <p className="text-sm font-medium">Visa</p>
                  </Button>
                  <Button
                    variant={cardType === "mastercard" ? "default" : "outline"}
                    className="h-20 flex flex-col items-center justify-center"
                    onClick={() => setCardType("mastercard")}
                    data-testid="button-card-type-mastercard"
                  >
                    <i className="fab fa-cc-mastercard text-2xl text-red-600 mb-2" />
                    <p className="text-sm font-medium">Mastercard</p>
                  </Button>
                </div>
              </div>

              <div>
                <Label className="text-sm font-medium mb-3 block">Initial Balance</Label>
                <div className="grid grid-cols-2 gap-3 mb-3">
                  {BALANCE_OPTIONS.map((amount) => (
                    <Button
                      key={amount}
                      variant={balance === amount.toString() ? "default" : "outline"}
                      onClick={() => setBalance(amount.toString())}
                      data-testid={`button-balance-${amount}`}
                    >
                      ${amount}
                    </Button>
                  ))}
                </div>
                <div className="space-y-3">
                  <Button
                    variant={balance === "custom" ? "default" : "outline"}
                    className="w-full"
                    onClick={() => setBalance("custom")}
                    data-testid="button-balance-custom"
                  >
                    Custom Amount
                  </Button>
                  {balance === "custom" && (
                    <Input
                      type="number"
                      placeholder="Enter custom amount"
                      value={customBalance}
                      onChange={(e) => setCustomBalance(e.target.value)}
                      min="10"
                      max="5000"
                      data-testid="input-custom-balance"
                    />
                  )}
                </div>
              </div>

              <div>
                <Label htmlFor="usage" className="text-sm font-medium mb-3 block">Card Usage</Label>
                <Select value={usage} onValueChange={setUsage}>
                  <SelectTrigger data-testid="select-usage">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="online">Online Payments Only</SelectItem>
                    <SelectItem value="global">Global Usage</SelectItem>
                    <SelectItem value="restricted">Restricted Merchants</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="bg-accent p-4 rounded-lg">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm">Card Balance:</span>
                  <span className="font-medium">${selectedBalance || "0.00"}</span>
                </div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm">Generation Fee:</span>
                  <span className="font-medium">$2.00</span>
                </div>
                <hr className="my-2 border-border" />
                <div className="flex justify-between items-center font-semibold">
                  <span>Total Cost:</span>
                  <span>${totalCost.toFixed(2)}</span>
                </div>
                <div className="mt-2 text-xs text-muted-foreground">
                  Available Balance: ${parseFloat(user?.balance || "0").toFixed(2)}
                </div>
              </div>

              <Button
                className="w-full"
                onClick={handleGenerate}
                disabled={!canGenerate || generateCardMutation.isPending}
                data-testid="button-generate"
              >
                <PlusCircle className="mr-2 h-4 w-4" />
                {generateCardMutation.isPending ? "Generating..." : "Generate Card"}
              </Button>
            </CardContent>
          </Card>

          {/* Card Preview */}
          <Card>
            <CardHeader>
              <CardTitle>Card Preview</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <CardPreview
                  cardType={cardType || "visa"}
                  balance={selectedBalance || "0"}
                  username={user?.username || "USER"}
                />

                <div className="space-y-3">
                  <div className="flex justify-between items-center p-3 bg-secondary rounded-lg">
                    <span className="text-sm font-medium">Status:</span>
                    <span className={`text-sm font-medium ${
                      canGenerate ? "text-green-600" : "text-orange-600"
                    }`}>
                      {canGenerate ? "Ready to Generate" : 
                       !cardType ? "Select Card Type" :
                       !selectedBalance ? "Select Balance" :
                       totalCost > parseFloat(user?.balance || "0") ? "Insufficient Balance" :
                       "Configure Card"}
                    </span>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-secondary rounded-lg">
                    <span className="text-sm font-medium">Available Balance:</span>
                    <span className="text-sm font-semibold text-green-600">
                      ${parseFloat(user?.balance || "0").toFixed(2)}
                    </span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
