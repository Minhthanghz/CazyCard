import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { useState } from "react";
import { CheckCircle, XCircle, Clock, ExternalLink } from "lucide-react";

export default function DepositApproval() {
  const { user: currentUser } = useAuth();
  const [selectedDeposit, setSelectedDeposit] = useState<any>(null);
  const [txHash, setTxHash] = useState<string>("");
  const [filter, setFilter] = useState<string>("pending");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: deposits = [], isLoading } = useQuery({
    queryKey: ["/api/admin/deposits"],
  }) as { data: any[]; isLoading: boolean };

  const approveDepositMutation = useMutation({
    mutationFn: async ({ depositId, status, txHash }: { depositId: string; status: string; txHash?: string }) => {
      const response = await apiRequest("PATCH", `/api/admin/deposits/${depositId}`, { status, txHash });
      return response.json();
    },
    onSuccess: (data, variables) => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/deposits"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      toast({
        title: variables.status === "approved" ? "Deposit Approved" : "Deposit Rejected",
        description: `Deposit has been ${variables.status} successfully.`,
      });
      setSelectedDeposit(null);
      setTxHash("");
    },
    onError: (error: any) => {
      toast({
        title: "Action Failed",
        description: error.message || "Failed to process deposit",
        variant: "destructive",
      });
    },
  });

  const filteredDeposits = (deposits as any[]).filter((deposit: any) => {
    if (filter === "all") return true;
    return deposit.status === filter;
  });

  const handleApprove = (deposit: any) => {
    setSelectedDeposit(deposit);
  };

  const handleReject = (depositId: string) => {
    approveDepositMutation.mutate({ depositId, status: "rejected" });
  };

  const handleApproveConfirm = () => {
    if (!selectedDeposit) return;
    
    approveDepositMutation.mutate({
      depositId: selectedDeposit.id,
      status: "approved",
      txHash: txHash || undefined,
    });
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "approved":
        return <Badge className="bg-green-100 text-green-800">Approved</Badge>;
      case "rejected":
        return <Badge className="bg-red-100 text-red-800">Rejected</Badge>;
      default:
        return <Badge className="bg-yellow-100 text-yellow-800">Pending</Badge>;
    }
  };

  const getBSCScanUrl = (txHash: string) => {
    return `https://bscscan.com/tx/${txHash}`;
  };

  if (!currentUser?.isAdmin) {
    return (
      <div className="p-6">
        <Card>
          <CardContent className="p-12">
            <div className="text-center">
              <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <XCircle className="h-8 w-8 text-red-600" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Access Denied</h3>
              <p className="text-muted-foreground">
                You don't have permission to access this page.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="p-6">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
          <p className="mt-2 text-muted-foreground">Loading deposits...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-foreground mb-2" data-testid="text-deposit-approval-title">
          Deposit Approval
        </h1>
        <p className="text-muted-foreground">
          Review and approve user deposit requests.
        </p>
      </div>

      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle>Deposit Requests</CardTitle>
            <div className="flex space-x-2">
              <Button
                variant={filter === "all" ? "default" : "secondary"}
                size="sm"
                onClick={() => setFilter("all")}
                data-testid="button-filter-all"
              >
                All
              </Button>
              <Button
                variant={filter === "pending" ? "default" : "secondary"}
                size="sm"
                onClick={() => setFilter("pending")}
                data-testid="button-filter-pending"
              >
                Pending
              </Button>
              <Button
                variant={filter === "approved" ? "default" : "secondary"}
                size="sm"
                onClick={() => setFilter("approved")}
                data-testid="button-filter-approved"
              >
                Approved
              </Button>
              <Button
                variant={filter === "rejected" ? "default" : "secondary"}
                size="sm"
                onClick={() => setFilter("rejected")}
                data-testid="button-filter-rejected"
              >
                Rejected
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {filteredDeposits.length === 0 ? (
            <div className="text-center py-12">
              <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
                <Clock className="h-8 w-8 text-muted-foreground" />
              </div>
              <h3 className="text-lg font-semibold mb-2">No Deposits Found</h3>
              <p className="text-muted-foreground">
                {filter === "pending" 
                  ? "No pending deposits to review." 
                  : `No ${filter} deposits found.`
                }
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-secondary">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                      User
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                      Amount
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                      Exact Amount
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                      Tx Hash
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                      Date
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                      Status
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                      Action
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {filteredDeposits.map((deposit: any) => (
                    <tr key={deposit.id}>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                            <span className="text-xs font-medium text-primary-foreground">
                              {deposit.userId.slice(0, 2).toUpperCase()}
                            </span>
                          </div>
                          <div className="ml-3">
                            <div className="text-sm font-medium" data-testid={`text-user-id-${deposit.id}`}>
                              User {deposit.userId.slice(0, 8)}...
                            </div>
                            <div className="text-xs text-muted-foreground">
                              ID: {deposit.userId.slice(0, 8)}
                            </div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium" data-testid={`text-amount-${deposit.id}`}>
                        ${parseFloat(deposit.amount).toFixed(2)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-mono" data-testid={`text-exact-amount-${deposit.id}`}>
                        {deposit.exactAmount} USDT
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        {deposit.txHash ? (
                          <div>
                            <div className="text-sm font-mono">{deposit.txHash.slice(0, 10)}...</div>
                            <a
                              href={getBSCScanUrl(deposit.txHash)}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-xs text-primary hover:underline flex items-center"
                              data-testid={`link-bscscan-${deposit.id}`}
                            >
                              View on BSCScan <ExternalLink className="h-3 w-3 ml-1" />
                            </a>
                          </div>
                        ) : (
                          <span className="text-xs text-muted-foreground">Not provided</span>
                        )}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-muted-foreground">
                        {new Date(deposit.createdAt).toLocaleDateString()}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        {getStatusBadge(deposit.status)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        {deposit.status === "pending" && (
                          <div className="flex space-x-2">
                            <Button
                              size="sm"
                              className="bg-green-600 hover:bg-green-700"
                              onClick={() => handleApprove(deposit)}
                              disabled={approveDepositMutation.isPending}
                              data-testid={`button-approve-${deposit.id}`}
                            >
                              <CheckCircle className="h-4 w-4 mr-1" />
                              Approve
                            </Button>
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => handleReject(deposit.id)}
                              disabled={approveDepositMutation.isPending}
                              data-testid={`button-reject-${deposit.id}`}
                            >
                              <XCircle className="h-4 w-4 mr-1" />
                              Reject
                            </Button>
                          </div>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Approval Confirmation Dialog */}
      <Dialog open={!!selectedDeposit} onOpenChange={() => setSelectedDeposit(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Approve Deposit</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <p className="text-sm text-muted-foreground mb-4">
                You are about to approve a deposit of <strong>${selectedDeposit?.amount}</strong> for user{" "}
                <strong>{selectedDeposit?.userId.slice(0, 8)}...</strong>
              </p>
              <Label htmlFor="txHash">Transaction Hash (Optional)</Label>
              <Input
                id="txHash"
                placeholder="0x..."
                value={txHash}
                onChange={(e) => setTxHash(e.target.value)}
                data-testid="input-tx-hash"
              />
              <p className="text-xs text-muted-foreground mt-1">
                Enter the transaction hash for verification (optional)
              </p>
            </div>
            <div className="flex space-x-2">
              <Button
                onClick={handleApproveConfirm}
                disabled={approveDepositMutation.isPending}
                className="flex-1 bg-green-600 hover:bg-green-700"
                data-testid="button-confirm-approve"
              >
                {approveDepositMutation.isPending ? "Approving..." : "Confirm Approval"}
              </Button>
              <Button
                variant="outline"
                onClick={() => setSelectedDeposit(null)}
                className="flex-1"
                data-testid="button-cancel-approve"
              >
                Cancel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
