import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "@/hooks/use-auth";
import { Users, CreditCard, DollarSign, TrendingUp, Activity, CheckCircle } from "lucide-react";

export default function SystemStats() {
  const { user: currentUser } = useAuth();

  const { data: stats = {}, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/admin/stats"],
  }) as { data: any; isLoading: boolean };

  const { data: users = [], isLoading: usersLoading } = useQuery({
    queryKey: ["/api/admin/users"],
  }) as { data: any[]; isLoading: boolean };

  const { data: deposits = [], isLoading: depositsLoading } = useQuery({
    queryKey: ["/api/admin/deposits"],
  }) as { data: any[]; isLoading: boolean };

  const isLoading = statsLoading || usersLoading || depositsLoading;

  if (!currentUser?.isAdmin) {
    return (
      <div className="p-6">
        <Card>
          <CardContent className="p-12">
            <div className="text-center">
              <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="h-8 w-8 text-red-600" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Access Denied</h3>
              <p className="text-muted-foreground">
                You don't have permission to access this page.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="p-6">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
          <p className="mt-2 text-muted-foreground">Loading statistics...</p>
        </div>
      </div>
    );
  }

  const activeUsers = (users as any[]).filter((user: any) => !user.isAdmin).length;
  const approvedDeposits = (deposits as any[]).filter((deposit: any) => deposit.status === "approved").length;
  const pendingDeposits = (deposits as any[]).filter((deposit: any) => deposit.status === "pending").length;
  const totalDepositAmount = (deposits as any[])
    .filter((deposit: any) => deposit.status === "approved")
    .reduce((sum: number, deposit: any) => sum + parseFloat(deposit.amount), 0);

  const recentUsers = (users as any[])
    .sort((a: any, b: any) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 5);

  const recentDeposits = (deposits as any[])
    .sort((a: any, b: any) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 5);

  return (
    <div className="p-6">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-foreground mb-2" data-testid="text-system-stats-title">
          System Statistics
        </h1>
        <p className="text-muted-foreground">
          Overview of platform performance and key metrics.
        </p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Users</p>
                <p className="text-2xl font-bold text-foreground" data-testid="text-stats-total-users">
                  {(stats as any)?.totalUsers || (users as any[]).length}
                </p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <Users className="text-blue-600 h-6 w-6" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Active Users</p>
                <p className="text-2xl font-bold text-foreground" data-testid="text-stats-active-users">
                  {activeUsers}
                </p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <Activity className="text-green-600 h-6 w-6" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Deposits</p>
                <p className="text-2xl font-bold text-foreground" data-testid="text-stats-total-deposits">
                  ${totalDepositAmount.toFixed(2)}
                </p>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                <DollarSign className="text-purple-600 h-6 w-6" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Pending Deposits</p>
                <p className="text-2xl font-bold text-foreground" data-testid="text-stats-pending-deposits">
                  {pendingDeposits}
                </p>
              </div>
              <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                <CheckCircle className="text-orange-600 h-6 w-6" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Additional Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Platform Balance</p>
                <p className="text-2xl font-bold text-foreground" data-testid="text-stats-platform-balance">
                  ${(stats as any)?.totalBalance || "0.00"}
                </p>
              </div>
              <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center">
                <TrendingUp className="text-indigo-600 h-6 w-6" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Transactions</p>
                <p className="text-2xl font-bold text-foreground" data-testid="text-stats-total-transactions">
                  {(stats as any)?.totalTransactions || "0"}
                </p>
              </div>
              <div className="w-12 h-12 bg-pink-100 rounded-lg flex items-center justify-center">
                <Activity className="text-pink-600 h-6 w-6" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Approved Deposits</p>
                <p className="text-2xl font-bold text-foreground" data-testid="text-stats-approved-deposits">
                  {approvedDeposits}
                </p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <CheckCircle className="text-green-600 h-6 w-6" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Recent Users */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Users</CardTitle>
          </CardHeader>
          <CardContent>
            {recentUsers.length === 0 ? (
              <p className="text-muted-foreground text-center py-8">No users found</p>
            ) : (
              <div className="space-y-4">
                {recentUsers.map((user: any) => (
                  <div key={user.id} className="flex items-center justify-between py-3 border-b border-border last:border-b-0">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                        <span className="text-xs font-medium text-primary-foreground">
                          {user.username.charAt(0).toUpperCase()}
                        </span>
                      </div>
                      <div>
                        <p className="text-sm font-medium" data-testid={`text-recent-user-${user.id}`}>
                          {user.username}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {user.isAdmin ? "Admin" : "User"}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">${parseFloat(user.balance).toFixed(2)}</p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(user.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Recent Deposits */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Deposits</CardTitle>
          </CardHeader>
          <CardContent>
            {recentDeposits.length === 0 ? (
              <p className="text-muted-foreground text-center py-8">No deposits found</p>
            ) : (
              <div className="space-y-4">
                {recentDeposits.map((deposit: any) => (
                  <div key={deposit.id} className="flex items-center justify-between py-3 border-b border-border last:border-b-0">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-secondary rounded-full flex items-center justify-center">
                        {deposit.status === "approved" && <CheckCircle className="text-green-600 h-4 w-4" />}
                        {deposit.status === "pending" && <Activity className="text-orange-600 h-4 w-4" />}
                        {deposit.status === "rejected" && <Users className="text-red-600 h-4 w-4" />}
                      </div>
                      <div>
                        <p className="text-sm font-medium">
                          User {deposit.userId.slice(0, 8)}...
                        </p>
                        <p className="text-xs text-muted-foreground capitalize">
                          {deposit.status} • {deposit.exactAmount} USDT
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">${parseFloat(deposit.amount).toFixed(2)}</p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(deposit.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
