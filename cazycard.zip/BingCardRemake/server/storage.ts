import { type User, type InsertUser, type LoginData, type Deposit, type InsertDeposit, type VirtualCard, type InsertCard, type Transaction } from "@shared/schema";
import { randomUUID } from "crypto";
import bcrypt from "bcrypt";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  authenticateUser(loginData: LoginData): Promise<User | null>;
  updateUserBalance(userId: string, newBalance: string): Promise<User | undefined>;
  getAllUsers(): Promise<User[]>;
  
  // Deposit operations
  createDeposit(userId: string, deposit: InsertDeposit): Promise<Deposit>;
  getDepositsByUser(userId: string): Promise<Deposit[]>;
  getPendingDeposits(): Promise<Deposit[]>;
  updateDepositStatus(depositId: string, status: string, txHash?: string): Promise<Deposit | undefined>;
  
  // Virtual card operations
  createVirtualCard(userId: string, card: InsertCard): Promise<VirtualCard>;
  getCardsByUser(userId: string): Promise<VirtualCard[]>;
  getCard(cardId: string): Promise<VirtualCard | undefined>;
  updateCardBalance(cardId: string, newBalance: string): Promise<VirtualCard | undefined>;
  updateCardStatus(cardId: string, isActive: boolean): Promise<VirtualCard | undefined>;
  
  // Transaction operations
  createTransaction(userId: string, type: string, amount: string, description: string, cardId?: string): Promise<Transaction>;
  getTransactionsByUser(userId: string): Promise<Transaction[]>;
  getAllTransactions(): Promise<Transaction[]>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private deposits: Map<string, Deposit>;
  private cards: Map<string, VirtualCard>;
  private transactions: Map<string, Transaction>;

  constructor() {
    this.users = new Map();
    this.deposits = new Map();
    this.cards = new Map();
    this.transactions = new Map();
    
    // Create default admin user
    this.initializeAdmin();
  }

  private async initializeAdmin() {
    const hashedPassword = await bcrypt.hash("admin123", 10);
    const adminUser: User = {
      id: randomUUID(),
      username: "admin",
      password: hashedPassword,
      balance: "10000.00",
      isAdmin: true,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.users.set(adminUser.id, adminUser);
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const hashedPassword = await bcrypt.hash(insertUser.password, 10);
    const id = randomUUID();
    const user: User = {
      ...insertUser,
      id,
      password: hashedPassword,
      balance: "0.00",
      isAdmin: false,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.users.set(id, user);
    return user;
  }

  async authenticateUser(loginData: LoginData): Promise<User | null> {
    const user = await this.getUserByUsername(loginData.username);
    if (!user) return null;
    
    const isValid = await bcrypt.compare(loginData.password, user.password);
    return isValid ? user : null;
  }

  async updateUserBalance(userId: string, newBalance: string): Promise<User | undefined> {
    const user = this.users.get(userId);
    if (!user) return undefined;
    
    const updatedUser = { ...user, balance: newBalance, updatedAt: new Date() };
    this.users.set(userId, updatedUser);
    return updatedUser;
  }

  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  async createDeposit(userId: string, deposit: InsertDeposit): Promise<Deposit> {
    const id = randomUUID();
    const randomDecimal = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
    const exactAmount = `${deposit.amount}.${randomDecimal}`;
    
    const newDeposit: Deposit = {
      ...deposit,
      id,
      userId,
      exactAmount,
      walletAddress: "0x463f5d4c8a62403a0a28a60712347ae215dab39c",
      txHash: null,
      status: "pending",
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.deposits.set(id, newDeposit);
    return newDeposit;
  }

  async getDepositsByUser(userId: string): Promise<Deposit[]> {
    return Array.from(this.deposits.values()).filter(d => d.userId === userId);
  }

  async getPendingDeposits(): Promise<Deposit[]> {
    return Array.from(this.deposits.values()).filter(d => d.status === "pending");
  }

  async updateDepositStatus(depositId: string, status: string, txHash?: string): Promise<Deposit | undefined> {
    const deposit = this.deposits.get(depositId);
    if (!deposit) return undefined;
    
    const updatedDeposit = { 
      ...deposit, 
      status, 
      txHash: txHash || deposit.txHash,
      updatedAt: new Date() 
    };
    this.deposits.set(depositId, updatedDeposit);
    
    // If approved, update user balance
    if (status === "approved") {
      const user = await this.getUser(deposit.userId);
      if (user) {
        const newBalance = (parseFloat(user.balance) + parseFloat(deposit.amount)).toFixed(2);
        await this.updateUserBalance(deposit.userId, newBalance);
        await this.createTransaction(deposit.userId, "deposit", deposit.amount, `Deposit approved - ${deposit.exactAmount} USDT`);
      }
    }
    
    return updatedDeposit;
  }

  async createVirtualCard(userId: string, card: InsertCard): Promise<VirtualCard> {
    const id = randomUUID();
    const cardNumber = this.generateCardNumber();
    const expiryDate = this.generateExpiryDate();
    const cvv = this.generateCVV();
    
    const newCard: VirtualCard = {
      ...card,
      id,
      userId,
      cardNumber,
      expiryDate,
      cvv,
      balance: card.balance || "0.00",
      isActive: true,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.cards.set(id, newCard);
    
    // Deduct balance from user and create transaction
    const user = await this.getUser(userId);
    if (user) {
      const totalCost = parseFloat(card.balance || "0") + 2; // $2 generation fee
      const newBalance = (parseFloat(user.balance) - totalCost).toFixed(2);
      await this.updateUserBalance(userId, newBalance);
      await this.createTransaction(userId, "card_generation", totalCost.toFixed(2), `Generated ${card.cardType} card ending in ${cardNumber.slice(-4)}`, id);
    }
    
    return newCard;
  }

  async getCardsByUser(userId: string): Promise<VirtualCard[]> {
    return Array.from(this.cards.values()).filter(c => c.userId === userId);
  }

  async getCard(cardId: string): Promise<VirtualCard | undefined> {
    return this.cards.get(cardId);
  }

  async updateCardBalance(cardId: string, newBalance: string): Promise<VirtualCard | undefined> {
    const card = this.cards.get(cardId);
    if (!card) return undefined;
    
    const updatedCard = { ...card, balance: newBalance, updatedAt: new Date() };
    this.cards.set(cardId, updatedCard);
    return updatedCard;
  }

  async updateCardStatus(cardId: string, isActive: boolean): Promise<VirtualCard | undefined> {
    const card = this.cards.get(cardId);
    if (!card) return undefined;
    
    const updatedCard = { ...card, isActive, updatedAt: new Date() };
    this.cards.set(cardId, updatedCard);
    return updatedCard;
  }

  async createTransaction(userId: string, type: string, amount: string, description: string, cardId?: string): Promise<Transaction> {
    const id = randomUUID();
    const transaction: Transaction = {
      id,
      userId,
      type,
      amount,
      description,
      cardId: cardId || null,
      createdAt: new Date(),
    };
    this.transactions.set(id, transaction);
    return transaction;
  }

  async getTransactionsByUser(userId: string): Promise<Transaction[]> {
    return Array.from(this.transactions.values()).filter(t => t.userId === userId);
  }

  async getAllTransactions(): Promise<Transaction[]> {
    return Array.from(this.transactions.values());
  }

  private generateCardNumber(): string {
    const prefix = "4532"; // Visa prefix
    const suffix = Math.floor(Math.random() * 100000000).toString().padStart(8, '0');
    return prefix + suffix;
  }

  private generateExpiryDate(): string {
    const now = new Date();
    const futureYear = now.getFullYear() + 3;
    const month = Math.floor(Math.random() * 12) + 1;
    return `${month.toString().padStart(2, '0')}/${futureYear.toString().slice(-2)}`;
  }

  private generateCVV(): string {
    return Math.floor(Math.random() * 900 + 100).toString();
  }
}

export const storage = new MemStorage();
