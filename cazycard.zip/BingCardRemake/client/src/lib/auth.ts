import { apiRequest } from "./queryClient";

export interface AuthUser {
  id: string;
  username: string;
  balance: string;
  isAdmin: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface LoginData {
  username: string;
  password: string;
}

export interface RegisterData {
  username: string;
  password: string;
}

export async function login(data: LoginData): Promise<{ user: AuthUser }> {
  const response = await apiRequest("POST", "/api/login", data);
  return response.json();
}

export async function register(data: RegisterData): Promise<{ user: AuthUser }> {
  const response = await apiRequest("POST", "/api/register", data);
  return response.json();
}

export async function logout(): Promise<void> {
  await apiRequest("POST", "/api/logout");
}

export async function getCurrentUser(): Promise<{ user: AuthUser }> {
  const response = await apiRequest("GET", "/api/me");
  return response.json();
}
