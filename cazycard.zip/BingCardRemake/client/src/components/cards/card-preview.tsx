import { cn } from "@/lib/utils";

interface CardPreviewProps {
  cardType: string;
  balance: string;
  username: string;
  className?: string;
}

export default function CardPreview({ cardType, balance, username, className }: CardPreviewProps) {
  const getCardGradient = (type: string) => {
    switch (type.toLowerCase()) {
      case "visa":
        return "gradient-card-blue";
      case "mastercard":
        return "gradient-card-green";
      default:
        return "gradient-card-purple";
    }
  };

  const getCardIcon = (type: string) => {
    switch (type.toLowerCase()) {
      case "visa":
        return "fab fa-cc-visa";
      case "mastercard":
        return "fab fa-cc-mastercard";
      default:
        return "fas fa-credit-card";
    }
  };

  return (
    <div className={cn("w-full h-56 rounded-xl p-6 text-white shadow-lg", getCardGradient(cardType), className)}>
      <div className="flex justify-between items-start mb-8">
        <div className="text-sm opacity-80">CazyCard</div>
        <i className={cn(getCardIcon(cardType), "text-2xl")} />
      </div>
      <div className="mb-6">
        <div className="text-lg font-mono tracking-widest">
          •••• •••• •••• ••••
        </div>
      </div>
      <div className="flex justify-between items-end">
        <div>
          <div className="text-xs opacity-80 mb-1">CARD HOLDER</div>
          <div className="text-sm font-medium uppercase">{username}</div>
        </div>
        <div>
          <div className="text-xs opacity-80 mb-1">BALANCE</div>
          <div className="text-sm font-medium">${parseFloat(balance).toFixed(2)}</div>
        </div>
      </div>
    </div>
  );
}
