import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Eye, EyeOff, Plus, MoreVertical } from "lucide-react";
import { cn } from "@/lib/utils";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface VirtualCardProps {
  card: {
    id: string;
    cardNumber: string;
    expiryDate: string;
    cvv: string;
    cardType: string;
    balance: string;
    isActive: boolean;
    createdAt: string;
  };
  onTopUp?: (cardId: string) => void;
  onToggleStatus?: (cardId: string, isActive: boolean) => void;
  onViewDetails?: (cardId: string) => void;
}

export default function VirtualCard({ card, onTopUp, onToggleStatus, onViewDetails }: VirtualCardProps) {
  const [showDetails, setShowDetails] = useState(false);

  const getCardGradient = (type: string) => {
    switch (type.toLowerCase()) {
      case "visa":
        return "gradient-card-blue";
      case "mastercard":
        return "gradient-card-green";
      default:
        return "gradient-card-purple";
    }
  };

  const getCardIcon = (type: string) => {
    switch (type.toLowerCase()) {
      case "visa":
        return "fab fa-cc-visa";
      case "mastercard":
        return "fab fa-cc-mastercard";
      default:
        return "fas fa-credit-card";
    }
  };

  const maskedCardNumber = `•••• •••• •••• ${card.cardNumber.slice(-4)}`;

  return (
    <Card className="overflow-hidden">
      {/* Card Visual */}
      <div className={cn("h-40 p-4 text-white relative", getCardGradient(card.cardType))}>
        <div className="flex justify-between items-start mb-6">
          <div className="text-sm opacity-80">CazyCard</div>
          <i className={cn(getCardIcon(card.cardType), "text-xl")} />
        </div>
        <div className="text-base font-mono tracking-wider mb-3">
          {showDetails ? card.cardNumber : maskedCardNumber}
        </div>
        <div className="flex justify-between text-xs">
          <span>{showDetails ? card.expiryDate : "••/••"}</span>
          <span className={cn("opacity-80", !card.isActive && "opacity-60")}>
            {card.isActive ? "Active" : "Locked"}
          </span>
        </div>
      </div>

      {/* Card Info */}
      <CardContent className="p-4">
        <div className="flex justify-between items-center mb-3">
          <span className="text-sm font-medium">Balance</span>
          <span className="text-lg font-bold text-green-600" data-testid={`text-card-balance-${card.id}`}>
            ${parseFloat(card.balance).toFixed(2)}
          </span>
        </div>
        <div className="flex justify-between items-center mb-4">
          <span className="text-sm text-muted-foreground">Created</span>
          <span className="text-sm">{new Date(card.createdAt).toLocaleDateString()}</span>
        </div>

        {showDetails && (
          <div className="mb-4 p-3 bg-secondary rounded-lg">
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span>CVV:</span>
                <span className="font-mono">{card.cvv}</span>
              </div>
              <div className="flex justify-between">
                <span>Expires:</span>
                <span className="font-mono">{card.expiryDate}</span>
              </div>
            </div>
          </div>
        )}

        <div className="flex space-x-2">
          <Button
            size="sm"
            variant={showDetails ? "secondary" : "default"}
            className="flex-1"
            onClick={() => setShowDetails(!showDetails)}
            data-testid={`button-toggle-details-${card.id}`}
          >
            {showDetails ? <EyeOff className="h-4 w-4 mr-1" /> : <Eye className="h-4 w-4 mr-1" />}
            {showDetails ? "Hide" : "View"}
          </Button>
          <Button
            size="sm"
            variant="secondary"
            className="flex-1"
            onClick={() => onTopUp?.(card.id)}
            data-testid={`button-topup-${card.id}`}
          >
            <Plus className="h-4 w-4 mr-1" />
            Top Up
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button size="sm" variant="secondary" data-testid={`button-menu-${card.id}`}>
                <MoreVertical className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent>
              <DropdownMenuItem onClick={() => onToggleStatus?.(card.id, !card.isActive)}>
                {card.isActive ? "Lock Card" : "Unlock Card"}
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => onViewDetails?.(card.id)}>
                View Details
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </CardContent>
    </Card>
  );
}
