import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import DepositForm from "@/components/deposit/deposit-form";
import { Plus, Clock, CheckCircle, XCircle } from "lucide-react";

export default function Wallet() {
  const { user } = useAuth();
  
  const { data: deposits = [] } = useQuery({
    queryKey: ["/api/deposits"],
  }) as { data: any[] };

  const { data: transactions = [] } = useQuery({
    queryKey: ["/api/transactions"],
  }) as { data: any[] };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "approved":
        return <CheckCircle className="text-green-600 h-4 w-4" />;
      case "rejected":
        return <XCircle className="text-red-600 h-4 w-4" />;
      default:
        return <Clock className="text-orange-600 h-4 w-4" />;
    }
  };

  return (
    <div className="p-6">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-foreground mb-2" data-testid="text-wallet-title">
          Wallet
        </h1>
        <p className="text-muted-foreground">
          Manage your funds and deposit history.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Balance Overview & Deposit Form */}
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardContent className="p-6">
              <h3 className="text-lg font-semibold mb-4">Current Balance</h3>
              <div className="text-4xl font-bold text-foreground mb-2" data-testid="text-current-balance">
                ${parseFloat(user?.balance || "0").toFixed(2)}
              </div>
              <p className="text-muted-foreground">Available for card generation</p>
            </CardContent>
          </Card>

          <DepositForm />
        </div>

        {/* Transaction History */}
        <div>
          <Card>
            <CardHeader>
              <CardTitle>Recent Transactions</CardTitle>
            </CardHeader>
            <CardContent>
              {(transactions as any[]).length === 0 ? (
                <p className="text-muted-foreground text-center py-8">No transactions yet</p>
              ) : (
                <div className="space-y-4">
                  {(transactions as any[]).slice(0, 5).map((transaction: any) => (
                    <div key={transaction.id} className="flex items-center justify-between py-3 border-b border-border last:border-b-0">
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                          <Plus className="text-green-600 text-xs h-3 w-3" />
                        </div>
                        <div>
                          <p className="text-sm font-medium capitalize">
                            {transaction.type.replace('_', ' ')}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {transaction.description}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className={`text-sm font-medium ${
                          transaction.type === "deposit" ? "text-green-600" : "text-red-600"
                        }`}>
                          {transaction.type === "deposit" ? "+" : "-"}${parseFloat(transaction.amount).toFixed(2)}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {new Date(transaction.createdAt).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {(deposits as any[]).length > 0 && (
            <Card className="mt-6">
              <CardHeader>
                <CardTitle>Deposit History</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {(deposits as any[]).slice(0, 5).map((deposit: any) => (
                    <div key={deposit.id} className="flex items-center justify-between py-3 border-b border-border last:border-b-0">
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                          {getStatusIcon(deposit.status)}
                        </div>
                        <div>
                          <p className="text-sm font-medium">Deposit Request</p>
                          <p className="text-xs text-muted-foreground capitalize">
                            {deposit.status} • {deposit.exactAmount} USDT
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-medium">${parseFloat(deposit.amount).toFixed(2)}</p>
                        <p className="text-xs text-muted-foreground">
                          {new Date(deposit.createdAt).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
