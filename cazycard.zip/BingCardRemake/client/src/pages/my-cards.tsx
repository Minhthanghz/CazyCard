import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import VirtualCard from "@/components/cards/virtual-card";
import { Plus } from "lucide-react";
import { Link } from "wouter";

export default function MyCards() {
  const [topUpCardId, setTopUpCardId] = useState<string>("");
  const [topUpAmount, setTopUpAmount] = useState<string>("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: cards = [], isLoading } = useQuery({
    queryKey: ["/api/cards"],
  }) as { data: any[]; isLoading: boolean };

  const topUpMutation = useMutation({
    mutationFn: async ({ cardId, amount }: { cardId: string; amount: string }) => {
      const response = await apiRequest("PATCH", `/api/cards/${cardId}/balance`, { amount });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cards"] });
      queryClient.invalidateQueries({ queryKey: ["/api/me"] });
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      toast({
        title: "Top Up Successful",
        description: "Card balance has been updated successfully.",
      });
      setTopUpCardId("");
      setTopUpAmount("");
    },
    onError: (error: any) => {
      toast({
        title: "Top Up Failed",
        description: error.message || "Failed to top up card",
        variant: "destructive",
      });
    },
  });

  const toggleStatusMutation = useMutation({
    mutationFn: async ({ cardId, isActive }: { cardId: string; isActive: boolean }) => {
      const response = await apiRequest("PATCH", `/api/cards/${cardId}/status`, { isActive });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cards"] });
      toast({
        title: "Card Status Updated",
        description: "Card status has been changed successfully.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Status Update Failed",
        description: error.message || "Failed to update card status",
        variant: "destructive",
      });
    },
  });

  const handleTopUp = (cardId: string) => {
    setTopUpCardId(cardId);
  };

  const handleTopUpSubmit = () => {
    if (!topUpAmount || parseFloat(topUpAmount) <= 0) {
      toast({
        title: "Invalid Amount",
        description: "Please enter a valid amount",
        variant: "destructive",
      });
      return;
    }
    
    topUpMutation.mutate({ cardId: topUpCardId, amount: topUpAmount });
  };

  const handleToggleStatus = (cardId: string, isActive: boolean) => {
    toggleStatusMutation.mutate({ cardId, isActive });
  };

  if (isLoading) {
    return (
      <div className="p-6">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
          <p className="mt-2 text-muted-foreground">Loading cards...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="mb-8">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold text-foreground mb-2" data-testid="text-cards-title">
              My Cards
            </h1>
            <p className="text-muted-foreground">
              Manage your virtual cards and their settings.
            </p>
          </div>
          <Link href="/generate">
            <Button data-testid="button-generate-new">
              <Plus className="mr-2 h-4 w-4" />
              Generate New Card
            </Button>
          </Link>
        </div>
      </div>

      {(cards as any[]).length === 0 ? (
        <div className="text-center py-12">
          <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
            <Plus className="h-8 w-8 text-muted-foreground" />
          </div>
          <h3 className="text-lg font-semibold mb-2">No Cards Yet</h3>
          <p className="text-muted-foreground mb-4">
            You haven't generated any virtual cards yet. Create your first card to get started.
          </p>
          <Link href="/generate">
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Generate Your First Card
            </Button>
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          {(cards as any[]).map((card: any) => (
            <VirtualCard
              key={card.id}
              card={card}
              onTopUp={handleTopUp}
              onToggleStatus={handleToggleStatus}
            />
          ))}
        </div>
      )}

      {/* Top Up Dialog */}
      <Dialog open={!!topUpCardId} onOpenChange={() => setTopUpCardId("")}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Top Up Card</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="amount">Amount to Add</Label>
              <Input
                id="amount"
                type="number"
                placeholder="0.00"
                value={topUpAmount}
                onChange={(e) => setTopUpAmount(e.target.value)}
                min="1"
                data-testid="input-topup-amount"
              />
            </div>
            <div className="flex space-x-2">
              <Button
                onClick={handleTopUpSubmit}
                disabled={topUpMutation.isPending}
                className="flex-1"
                data-testid="button-confirm-topup"
              >
                {topUpMutation.isPending ? "Processing..." : "Confirm Top Up"}
              </Button>
              <Button
                variant="outline"
                onClick={() => setTopUpCardId("")}
                className="flex-1"
                data-testid="button-cancel-topup"
              >
                Cancel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
