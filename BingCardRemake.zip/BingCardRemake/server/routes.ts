import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import session from "express-session";
import MemoryStore from "memorystore";
import { insertUserSchema, loginSchema, insertDepositSchema, insertCardSchema } from "@shared/schema";

const MemStore = MemoryStore(session);

declare module "express-session" {
  interface SessionData {
    userId?: string;
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Session middleware
  app.use(session({
    secret: process.env.SESSION_SECRET || "cazycard-secret-key",
    resave: false,
    saveUninitialized: false,
    store: new MemStore({
      checkPeriod: 86400000 // prune expired entries every 24h
    }),
    cookie: {
      secure: false,
      httpOnly: true,
      maxAge: 24 * 60 * 60 * 1000 // 24 hours
    }
  }));

  // Middleware to check authentication
  const requireAuth = (req: any, res: any, next: any) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: "Authentication required" });
    }
    next();
  };

  const requireAdmin = async (req: any, res: any, next: any) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: "Authentication required" });
    }
    const user = await storage.getUser(req.session.userId);
    if (!user || !user.isAdmin) {
      return res.status(403).json({ message: "Admin access required" });
    }
    next();
  };

  // Authentication routes
  app.post("/api/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if username exists
      const existingUser = await storage.getUserByUsername(userData.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }
      
      const user = await storage.createUser(userData);
      req.session.userId = user.id;
      
      const { password, ...userWithoutPassword } = user;
      res.json({ user: userWithoutPassword });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.post("/api/login", async (req, res) => {
    try {
      const loginData = loginSchema.parse(req.body);
      const user = await storage.authenticateUser(loginData);
      
      if (!user) {
        return res.status(401).json({ message: "Invalid username or password" });
      }
      
      req.session.userId = user.id;
      const { password, ...userWithoutPassword } = user;
      res.json({ user: userWithoutPassword });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.post("/api/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Could not log out" });
      }
      res.json({ message: "Logged out successfully" });
    });
  });

  app.get("/api/me", requireAuth, async (req, res) => {
    try {
      const user = await storage.getUser(req.session.userId!);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      const { password, ...userWithoutPassword } = user;
      res.json({ user: userWithoutPassword });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Deposit routes
  app.post("/api/deposits", requireAuth, async (req, res) => {
    try {
      const depositData = insertDepositSchema.parse(req.body);
      const deposit = await storage.createDeposit(req.session.userId!, depositData);
      res.json(deposit);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.get("/api/deposits", requireAuth, async (req, res) => {
    try {
      const deposits = await storage.getDepositsByUser(req.session.userId!);
      res.json(deposits);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Virtual card routes
  app.post("/api/cards", requireAuth, async (req, res) => {
    try {
      const cardData = insertCardSchema.parse(req.body);
      
      // Check if user has sufficient balance
      const user = await storage.getUser(req.session.userId!);
      const totalCost = parseFloat(cardData.balance || "0") + 2; // $2 generation fee
      
      if (!user || parseFloat(user.balance) < totalCost) {
        return res.status(400).json({ message: "Insufficient balance" });
      }
      
      const card = await storage.createVirtualCard(req.session.userId!, cardData);
      res.json(card);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.get("/api/cards", requireAuth, async (req, res) => {
    try {
      const cards = await storage.getCardsByUser(req.session.userId!);
      res.json(cards);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.patch("/api/cards/:id/balance", requireAuth, async (req, res) => {
    try {
      const { amount } = req.body;
      const cardId = req.params.id;
      
      const card = await storage.getCard(cardId);
      if (!card || card.userId !== req.session.userId!) {
        return res.status(404).json({ message: "Card not found" });
      }
      
      const user = await storage.getUser(req.session.userId!);
      if (!user || parseFloat(user.balance) < parseFloat(amount)) {
        return res.status(400).json({ message: "Insufficient balance" });
      }
      
      const newCardBalance = (parseFloat(card.balance) + parseFloat(amount)).toFixed(2);
      const newUserBalance = (parseFloat(user.balance) - parseFloat(amount)).toFixed(2);
      
      await storage.updateCardBalance(cardId, newCardBalance);
      await storage.updateUserBalance(req.session.userId!, newUserBalance);
      await storage.createTransaction(req.session.userId!, "card_topup", amount, `Top up card ending in ${card.cardNumber.slice(-4)}`, cardId);
      
      const updatedCard = await storage.getCard(cardId);
      res.json(updatedCard);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.patch("/api/cards/:id/status", requireAuth, async (req, res) => {
    try {
      const { isActive } = req.body;
      const cardId = req.params.id;
      
      const card = await storage.getCard(cardId);
      if (!card || card.userId !== req.session.userId!) {
        return res.status(404).json({ message: "Card not found" });
      }
      
      const updatedCard = await storage.updateCardStatus(cardId, isActive);
      res.json(updatedCard);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Transaction routes
  app.get("/api/transactions", requireAuth, async (req, res) => {
    try {
      const transactions = await storage.getTransactionsByUser(req.session.userId!);
      res.json(transactions);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Admin routes
  app.get("/api/admin/users", requireAdmin, async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      const usersWithoutPassword = users.map(({ password, ...user }) => user);
      res.json(usersWithoutPassword);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/admin/deposits", requireAdmin, async (req, res) => {
    try {
      const deposits = await storage.getPendingDeposits();
      res.json(deposits);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.patch("/api/admin/deposits/:id", requireAdmin, async (req, res) => {
    try {
      const { status, txHash } = req.body;
      const depositId = req.params.id;
      
      const updatedDeposit = await storage.updateDepositStatus(depositId, status, txHash);
      if (!updatedDeposit) {
        return res.status(404).json({ message: "Deposit not found" });
      }
      
      res.json(updatedDeposit);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.patch("/api/admin/users/:id/balance", requireAdmin, async (req, res) => {
    try {
      const { balance } = req.body;
      const userId = req.params.id;
      
      const updatedUser = await storage.updateUserBalance(userId, balance);
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      await storage.createTransaction(userId, "balance_adjustment", balance, "Admin balance adjustment");
      const { password, ...userWithoutPassword } = updatedUser;
      res.json(userWithoutPassword);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.get("/api/admin/stats", requireAdmin, async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      const transactions = await storage.getAllTransactions();
      
      const stats = {
        totalUsers: users.length,
        totalBalance: users.reduce((sum, user) => sum + parseFloat(user.balance), 0).toFixed(2),
        totalTransactions: transactions.length,
        totalVolume: transactions.reduce((sum, tx) => sum + parseFloat(tx.amount), 0).toFixed(2),
      };
      
      res.json(stats);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
