import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Wallet, CreditCard, TrendingUp, Calendar, Plus, Eye, ArrowRight } from "lucide-react";

export default function Dashboard() {
  const { user } = useAuth();
  
  const { data: cards = [] } = useQuery({
    queryKey: ["/api/cards"],
  }) as { data: any[] };

  const { data: transactions = [] } = useQuery({
    queryKey: ["/api/transactions"],
  }) as { data: any[] };

  const activeCards = (cards as any[]).filter((card: any) => card.isActive).length;
  const totalSpent = (transactions as any[])
    .filter((tx: any) => tx.type === "card_generation" || tx.type === "card_usage")
    .reduce((sum: number, tx: any) => sum + parseFloat(tx.amount), 0);
  
  const thisMonthTransactions = (transactions as any[]).filter((tx: any) => {
    const txDate = new Date(tx.createdAt);
    const now = new Date();
    return txDate.getMonth() === now.getMonth() && txDate.getFullYear() === now.getFullYear();
  });
  const monthlySpent = thisMonthTransactions
    .reduce((sum: number, tx: any) => sum + parseFloat(tx.amount), 0);

  const recentActivities = (transactions as any[]).slice(0, 3);

  return (
    <div className="p-6">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-foreground mb-2" data-testid="text-dashboard-title">
          Dashboard
        </h1>
        <p className="text-muted-foreground">
          Welcome back! Here's an overview of your account.
        </p>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Wallet Balance</p>
                <p className="text-2xl font-bold text-foreground" data-testid="text-wallet-balance">
                  ${parseFloat(user?.balance || "0").toFixed(2)}
                </p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <Wallet className="text-green-600 text-lg h-6 w-6" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Active Cards</p>
                <p className="text-2xl font-bold text-foreground" data-testid="text-active-cards">
                  {activeCards}
                </p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <CreditCard className="text-blue-600 text-lg h-6 w-6" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Spent</p>
                <p className="text-2xl font-bold text-foreground" data-testid="text-total-spent">
                  ${totalSpent.toFixed(2)}
                </p>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                <TrendingUp className="text-purple-600 text-lg h-6 w-6" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">This Month</p>
                <p className="text-2xl font-bold text-foreground" data-testid="text-monthly-spent">
                  ${monthlySpent.toFixed(2)}
                </p>
              </div>
              <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                <Calendar className="text-orange-600 text-lg h-6 w-6" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions & Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <Link href="/generate">
              <Button className="w-full justify-between" size="lg" data-testid="button-generate-card">
                <div className="flex items-center">
                  <Plus className="mr-3 h-5 w-5" />
                  <span className="font-medium">Generate New Card</span>
                </div>
                <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
            <Link href="/wallet">
              <Button variant="secondary" className="w-full justify-between" size="lg" data-testid="button-add-funds">
                <div className="flex items-center">
                  <Wallet className="mr-3 h-5 w-5" />
                  <span className="font-medium">Add Funds</span>
                </div>
                <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
            <Link href="/cards">
              <Button variant="secondary" className="w-full justify-between" size="lg" data-testid="button-view-cards">
                <div className="flex items-center">
                  <Eye className="mr-3 h-5 w-5" />
                  <span className="font-medium">View All Cards</span>
                </div>
                <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
          </CardContent>
        </Card>

        {/* Recent Activity */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
          </CardHeader>
          <CardContent>
            {recentActivities.length === 0 ? (
              <p className="text-muted-foreground text-center py-8">No recent activity</p>
            ) : (
              <div className="space-y-4">
                {recentActivities.map((activity: any) => (
                  <div key={activity.id} className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                      {activity.type === "deposit" && <Plus className="text-green-600 text-sm h-4 w-4" />}
                      {activity.type === "card_generation" && <CreditCard className="text-blue-600 text-sm h-4 w-4" />}
                      {activity.type === "card_topup" && <Wallet className="text-purple-600 text-sm h-4 w-4" />}
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-medium">{activity.description}</p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(activity.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className={`text-sm font-medium ${
                        activity.type === "deposit" ? "text-green-600" : 
                        activity.amount > 0 ? "text-red-600" : "text-foreground"
                      }`}>
                        {activity.type === "deposit" ? "+" : "-"}${parseFloat(activity.amount).toFixed(2)}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
