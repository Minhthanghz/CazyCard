import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useState } from "react";
import { Plus, CreditCard, Wallet, ArrowUpDown } from "lucide-react";

export default function Transactions() {
  const [filter, setFilter] = useState<string>("all");
  
  const { data: transactions = [], isLoading } = useQuery({
    queryKey: ["/api/transactions"],
  }) as { data: any[]; isLoading: boolean };

  const filteredTransactions = (transactions as any[]).filter((tx: any) => {
    if (filter === "all") return true;
    return tx.type === filter;
  });

  const getTransactionIcon = (type: string) => {
    switch (type) {
      case "deposit":
        return <Plus className="h-4 w-4 text-green-600" />;
      case "card_generation":
        return <CreditCard className="h-4 w-4 text-blue-600" />;
      case "card_topup":
        return <Wallet className="h-4 w-4 text-purple-600" />;
      default:
        return <ArrowUpDown className="h-4 w-4 text-gray-600" />;
    }
  };

  const getTransactionColor = (type: string) => {
    switch (type) {
      case "deposit":
        return "text-green-600";
      case "card_generation":
      case "card_topup":
        return "text-red-600";
      default:
        return "text-foreground";
    }
  };

  const formatTransactionType = (type: string) => {
    return type.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
  };

  if (isLoading) {
    return (
      <div className="p-6">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
          <p className="mt-2 text-muted-foreground">Loading transactions...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="mb-8">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold text-foreground mb-2" data-testid="text-transactions-title">
              Transactions
            </h1>
            <p className="text-muted-foreground">
              View your complete transaction history and activity.
            </p>
          </div>
          <Select value={filter} onValueChange={setFilter}>
            <SelectTrigger className="w-48" data-testid="select-filter">
              <SelectValue placeholder="Filter transactions" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Transactions</SelectItem>
              <SelectItem value="deposit">Deposits</SelectItem>
              <SelectItem value="card_generation">Card Generation</SelectItem>
              <SelectItem value="card_topup">Card Top Up</SelectItem>
              <SelectItem value="balance_adjustment">Balance Adjustment</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {filteredTransactions.length === 0 ? (
        <Card>
          <CardContent className="p-12">
            <div className="text-center">
              <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
                <ArrowUpDown className="h-8 w-8 text-muted-foreground" />
              </div>
              <h3 className="text-lg font-semibold mb-2">No Transactions Found</h3>
              <p className="text-muted-foreground">
                {filter === "all" 
                  ? "You haven't made any transactions yet." 
                  : `No ${formatTransactionType(filter).toLowerCase()} transactions found.`
                }
              </p>
            </div>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardHeader>
            <CardTitle>Transaction History</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {filteredTransactions.map((transaction: any) => (
                <div key={transaction.id} className="flex items-center justify-between p-4 border border-border rounded-lg">
                  <div className="flex items-center space-x-4">
                    <div className="w-10 h-10 bg-secondary rounded-full flex items-center justify-center">
                      {getTransactionIcon(transaction.type)}
                    </div>
                    <div>
                      <p className="font-medium" data-testid={`text-transaction-type-${transaction.id}`}>
                        {formatTransactionType(transaction.type)}
                      </p>
                      <p className="text-sm text-muted-foreground" data-testid={`text-transaction-desc-${transaction.id}`}>
                        {transaction.description}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(transaction.createdAt).toLocaleString()}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className={`text-lg font-semibold ${getTransactionColor(transaction.type)}`}>
                      {transaction.type === "deposit" ? "+" : "-"}${parseFloat(transaction.amount).toFixed(2)}
                    </p>
                    <Badge variant="secondary" className="text-xs">
                      {transaction.type.replace(/_/g, ' ')}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
