import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { CreditCard, User, Wallet } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export default function Navbar() {
  const { user, logout } = useAuth();

  return (
    <header className="bg-card border-b border-border sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-4">
            <div className="flex items-center">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <CreditCard className="text-primary-foreground text-lg" />
              </div>
              <span className="ml-3 text-xl font-bold text-foreground">CazyCard</span>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <div className="flex items-center bg-secondary px-3 py-2 rounded-lg">
              <Wallet className="text-muted-foreground mr-2 h-4 w-4" />
              <span className="text-sm font-medium" data-testid="text-balance">
                ${parseFloat(user?.balance || "0").toFixed(2)}
              </span>
            </div>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="flex items-center space-x-2 bg-accent hover:bg-secondary" data-testid="button-user-menu">
                  <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                    <User className="text-primary-foreground text-sm h-4 w-4" />
                  </div>
                  <span className="text-sm font-medium">{user?.username}</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={logout} data-testid="button-logout">
                  Logout
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>
    </header>
  );
}
